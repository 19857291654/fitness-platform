import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Home from './pages/Home';  // 假设你已经有一个 Home 页面
import Trainer from './pages/Trainer';  // 新建一个 Trainer 页面

function App() {
  const member = JSON.parse(localStorage.getItem('member'));

  return (
    <Router>
      <Routes>
        {/* 登录路由 */}
        <Route path="/login" element={<Login />} />
        {/* 根据 role 判断跳转到主页还是教练页面 */}
        <Route path="/home" element={member?.role === 'trainer' ? <Navigate to="/trainer" /> : <Home />} />
        <Route path="/trainer" element={member?.role === 'trainer' ? <Trainer /> : <Navigate to="/home" />} />
        {/* 其他页面 */}
      </Routes>
    </Router>
  );
}

export default App;
