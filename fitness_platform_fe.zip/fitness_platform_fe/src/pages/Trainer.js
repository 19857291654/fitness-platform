import React, { useEffect, useState } from 'react';
import {
  getAllMembers,
  approveMember,
  getAllTrainingRequests,
  respondToTrainingRequest,
  getAllTrainingSessions, // 引入获取所有课程信息的接口
  recordTrainingHistory,
  recommendTrainer,
  completeSession,
  bookTrainingSession,
} from '../api';
import { List, Card,Checkbox, Spin, Button, message, Pagination, Tabs, Table } from 'antd';
import { Modal, Form, Input, } from 'antd';
import moment from 'moment';  // 导入 moment 库，用于日期处理
import { DatePicker } from 'antd';  // 导入 antd 的 DatePicker 组件，用于日期选择

const { TabPane } = Tabs;

const Trainer = () => {
  const [members, setMembers] = useState([]); // 存储会员数据
  const [loading, setLoading] = useState(true); // 控制加载状态
  const [error, setError] = useState(null); // 存储错误信息
  const [currentPage, setCurrentPage] = useState(1); // 当前页
  const [pageSize, setPageSize] = useState(6); // 每页显示数量
  const [trainingRequests, setTrainingRequests] = useState([]); // 存储训练请求
  const [trainingRequestsLoading, setTrainingRequestsLoading] = useState(true); // 控制训练请求加载状态
  const [trainingSessions, setTrainingSessions] = useState([]); // 存储所有课程信息
  const [trainingSessionsLoading, setTrainingSessionsLoading] = useState(true); // 控制课程信息加载状态
  const [currentSessionId, setCurrentSessionId] = useState(null); // 当前正在上课的课程ID
  const [recommendedTrainerId, setRecommendedTrainerId] = useState('');
  const [isBookingModalVisible, setIsBookingModalVisible] = useState(false); // 预约表单
  const [form] = Form.useForm(); // 表单实例
  const [bookingForm] = Form.useForm(); // 独立表单实例
  const [isModalVisible, setIsModalVisible] = useState(false); // 控制表单弹出框的可见性
  // 获取所有会员数据
  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const data = await getAllMembers();
        setMembers(data.members);
      } catch (err) {
        setError('获取会员数据失败');
      } finally {
        setLoading(false);
      }
    };

    fetchMembers();
  }, []);

  // 获取所有训练请求数据
  useEffect(() => {
    const fetchTrainingRequests = async () => {
      try {
        const data = await getAllTrainingRequests();
        setTrainingRequests(data.trainingRequests);
      } catch (err) {
        setError('获取训练请求数据失败');
      } finally {
        setTrainingRequestsLoading(false);
      }
    };

    fetchTrainingRequests();
  }, []);

 // 获取所有课程信息
 useEffect(() => {
  const fetchTrainingSessions = async () => {
    try {
      const data = await getAllTrainingSessions(); // 假设这是你获取课程信息的函数
      setTrainingSessions(data.sessions);
    } catch (err) {
      message.error('获取课程信息失败');
    } finally {
      setTrainingSessionsLoading(false);
    }
  };

  fetchTrainingSessions();
}, []);

  // 审批会员
  const handleApprove = async (id) => {
    try {
      const result = await approveMember(id);
      message.success(result.message || '会员审批成功');
      setMembers(prevMembers =>
        prevMembers.map(member =>
          member.id === id ? { ...member, approved: true } : member
        )
      );
    } catch (error) {
      message.error('审批会员失败');
    }
  };

  // 响应训练请求
  const handleResponse = async (id, response) => {
    try {
      const result = await respondToTrainingRequest(id, response);
      message.success(result.message || '训练请求响应成功');
      setTrainingRequests(prevRequests =>
        prevRequests.map(request =>
          request.id === id ? { ...request, status: response === 'accept' ? 'accepted' : 'rejected' } : request
        )
      );
    } catch (error) {
      message.error('响应训练请求失败');
    }
  };

//推荐其他教练
const handleRecommendTrainer = async (id, recommendedTrainerId) => {
  setLoading(true);
  try {
    const result = await recommendTrainer(id, recommendedTrainerId);
    message.success('成功推荐新的教练');
    console.log(result);
  } catch (error) {
    message.error('推荐教练失败，请稍后再试');
  } finally {
    setLoading(false);
  }
};

  // 分页变化时
  const handlePageChange = (page, pageSize) => {
    setCurrentPage(page);
    setPageSize(pageSize);
  };

  // 训练请求表格列配置
  const trainingRequestsColumns = [
    { title: '会员ID', dataIndex: 'member_id', key: 'member_id' },
    { title: '教练ID', dataIndex: 'trainer_id', key: 'trainer_id' },
    { title: '目标', dataIndex: 'goal', key: 'goal' },
    { title: '状态', dataIndex: 'status', key: 'status' },
    { title: '推荐教练ID', dataIndex: 'recommended_trainer_id', key: 'recommended_trainer_id' },
    {
      title: '操作',
      key: 'action',
      render: (text, record) => (
        <div>
          {record.status === 'pending' && (
            <Button onClick={() => handleResponse(record.id, 'accept')} type="primary" style={{ marginRight: 8 }}>
              接受
            </Button>
          )}
          {record.status === 'pending' && (
            <Button onClick={() => handleResponse(record.id, 'reject')} type="danger" style={{ marginRight: 8 }}>
              拒绝
            </Button>
          )}
          {record.status === 'pending' && (
           <>
           <Input
             type="text"
             placeholder="请输入推荐教练ID"
             value={recommendedTrainerId}
             onChange={(e) => setRecommendedTrainerId(e.target.value)}
           />
           <Button
             onClick={() => handleRecommendTrainer(record.id, recommendedTrainerId)}
             type="default"
             loading={loading}
             disabled={!recommendedTrainerId} // 确保推荐教练ID不能为空
           >
             推荐其他教练
           </Button>
         </>
          )}
        </div>
      ),
    },
  ];
  

// 课程信息表格列配置
const trainingSessionsColumns = [
  { title: '课程ID', dataIndex: 'id', key: 'id' },
  { title: '会员ID', dataIndex: 'member_id', key: 'member_id' },
  { title: '教练ID', dataIndex: 'trainer_id', key: 'trainer_id' },
  { title: '时间', dataIndex: 'session_date', key: 'session_date', render: (date) => new Date(date).toLocaleString() },
  { title: '地点', dataIndex: 'location', key: 'location' },
  { title: '状态', dataIndex: 'status', key: 'status' },
  {
    title: '操作',
    key: 'action',
    render: (_, record) => {
      if (record.status === 'booked') {
        // 'booked' 状态上课
        return (
          <Button
            type="primary"
            onClick={() => handleStartClass(record.id)} // 点击按钮时执行的操作
          >
            上课
          </Button>
        );
      } else if (record.status === 'completed') {
        // 'completed' 状态预约下次课程
        return (
            <Button
              type="primary"
              onClick={() => handleBookNextSession(record.id)} // 打开预约下次课程表单
            >
              预约下次课程
            </Button>
        );
      }
      return null; // 如果状态不是 booked 或 completed，返回 null（不显示按钮）
    },
  },
];


// 上课按钮的处理函数
const handleStartClass = (sessionId) => {
  setCurrentSessionId(sessionId);
  setIsModalVisible(true); // 显示表单
};

// 预约下次课程按钮的处理函数
const handleBookNextSession = (sessionId) => {
  setCurrentSessionId(sessionId);
  setIsBookingModalVisible(true); // 打开预约表单
};

// 提交上课的表单
const handleSubmit = async (values) => {
  try {
    // 准备提交数据
    const historyData = {
      member_id: trainingSessions.find(session => session.id === currentSessionId)?.member_id,
      trainer_id: trainingSessions.find(session => session.id === currentSessionId)?.trainer_id,
      session_id: currentSessionId,
      workout_type: values.workout_type,
      sets: values.sets,
      reps: values.reps,
      weight: values.weight,
      heart_rate: values.heart_rate,
      calories_burned: values.calories_burned,
      performance: values.performance,  // 假设 performance 是通过某个字段传递的
      duration: values.duration,        // 假设 duration 是通过某个字段传递的
    };

    // 调用记录训练历史的接口
    const result = await recordTrainingHistory(historyData);
    
    if (result) {
      // 提交训练历史成功后，调用 completeSession 更新课程状态为 "已上课"
      await completeSession(currentSessionId);  // 这里传入当前课程的 ID
      message.success('训练历史提交成功，课程状态已更新为 "已经上课"');
      setIsModalVisible(false); // 关闭表单
      form.resetFields(); // 重置表单
    } else {
      message.error('提交失败，请稍后重试');
    }
  } catch (error) {
    console.error(error);
    message.error('提交失败');
  }
};
//提交预约下次的表单
const handleBookSession = async (values) => {
  try {
    // 1. 验证当前课程信息
    const session = trainingSessions.find(s => s.id === currentSessionId);
    if (!session) {
      message.error('找不到对应的课程信息');
      return;
    }

    // 2. 参数验证
    if (typeof session.trainer_id !== 'number') {
      message.error('无效的教练ID格式');
      return;
    }

    if (typeof session.member_id !== 'number') {
      message.error('无效的会员ID格式');
      return;
    }

    if (!moment(values.session_date).isValid()) {
      message.error('请选择有效的预约时间');
      return;
    }

    if (!values.location || values.location.trim() === '') {
      message.error('请输入有效的地点');
      return;
    }

    // 3. 转换日期格式
    const formattedDate = moment(values.session_date).toISOString();

    // 调试日志（正式环境可移除）
    console.log('提交参数详情：', {
      trainer_id: session.trainer_id,
      member_id: session.member_id,
      session_date: formattedDate,
      location: values.location
    });

    // 4. 调用API
    const result = await bookTrainingSession(
      session.trainer_id,
      session.member_id,
      formattedDate,
      values.location.trim()
    );

    // 5. 处理成功结果
    if (result && result.success) {
      message.success('课程预约成功！');
      
      // 关闭弹窗并重置表单
      setIsBookingModalVisible(false);
      bookingForm.resetFields();

      // 刷新课程列表
      try {
        const { data } = await getAllTrainingSessions();
        setTrainingSessions(data.sessions);
      } catch (refreshError) {
        console.error('刷新课程列表失败:', refreshError);
        message.warning('预约成功，但刷新列表失败');
      }

      return;
    }

    // 处理未预期的响应格式
    message.error(result?.message || '未知的服务器响应');

  } catch (error) {
    console.error('预约失败详情:', error);

    // 6. 处理错误信息
    const errorMessage = error.message || '未知错误';
    let displayMessage = `预约失败: ${errorMessage}`;

    // 处理字段级错误（假设后端返回格式为 { errors: [{ field, message }] }）
    if (error.errors && Array.isArray(error.errors)) {
      error.errors.forEach(err => {
        message.error(`${err.field}: ${err.message}`);
      });
      return;
    }

    // 处理特定错误状态码
    if (error.statusCode) {
      switch (error.statusCode) {
        case 400:
          displayMessage = '请求参数不合法';
          break;
        case 409:
          displayMessage = '该时间段已有预约';
          break;
        case 403:
          displayMessage = '没有预约权限';
          break;
      }
    }

    message.error(displayMessage);
  } finally {
    // 7. 清除当前课程ID
    setCurrentSessionId(null);
  }
};


  // 分页的起始位置
  const startIndex = (currentPage - 1) * pageSize;
  const currentMembers = members.slice(startIndex, startIndex + pageSize);

  return (
    <div style={{ padding: '20px' }}>
      <h1>欢迎, 教练!</h1>
      <p>这是您的教练后台管理页面。</p>

      <Tabs defaultActiveKey="1">
        {/* 会员管理 Tab */}
        <TabPane tab="会员管理" key="1">
          <h2>所有会员</h2>
          <List
            grid={{ gutter: 16, column: 3 }}
            dataSource={currentMembers}
            renderItem={member => (
              <List.Item>
                <Card title={member.name} bordered={false} style={{ width: 300 }}>
                  <p><strong>电子邮件：</strong> {member.email}</p>
                  <p><strong>角色：</strong> {member.role}</p>
                  <p><strong>是否已审批：</strong> {member.approved ? '是' : '否'}</p>
                  <p><strong>地址：</strong> {member.address}</p>
                  <p><strong>生日：</strong> {new Date(member.birth_date).toLocaleDateString()}</p>
                  {!member.approved && (
                    <Button
                      type="primary"
                      onClick={() => handleApprove(member.id)}
                      disabled={member.approved}
                    >
                      审批
                    </Button>
                  )}
                </Card>
              </List.Item>
            )}
          />
          <Pagination
            current={currentPage}
            pageSize={pageSize}
            total={members.length}
            onChange={handlePageChange}
            showSizeChanger
            pageSizeOptions={['6', '12', '18']}
            showTotal={total => `总共 ${total} 条`}
            style={{ marginTop: 20, textAlign: 'center' }}
          />
        </TabPane>

        {/* 训练请求管理 Tab */}
        <TabPane tab="训练请求管理" key="2">
          <h2>所有训练请求</h2>
          {trainingRequestsLoading ? (
            <Spin tip="加载训练请求..." size="large" />
          ) : (
            <Table
              columns={trainingRequestsColumns}
              dataSource={trainingRequests}
              rowKey="id"
              pagination={false}
            />
          )}
        </TabPane>

        {/* 上课管理 Tab */}
        <TabPane tab="上课管理" key="3">
          <h2>所有课程信息</h2>
          {trainingSessionsLoading ? (
            <Spin tip="加载课程信息..." size="large" />
          ) : (
            <Table
              columns={trainingSessionsColumns}
              dataSource={trainingSessions}
              rowKey="id"
              pagination={false}
            />
          )}
        </TabPane>
      </Tabs>

    {/* 上课表单弹出框 */}
    <Modal
        title="开始上课"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form
          form={form}
          onFinish={handleSubmit}
          initialValues={{
            workout_type: '',
            sets: 4,
            reps: 8,
            weight: 100,
            heart_rate: 120,
            calories_burned: 300,
            performance: false,  // 默认值为 false，表示未完成训练目标
           duration: 0,         // 默认值为 0，表示训练时长为 0 秒
          }}
        >
          <Form.Item
            label="训练类型"
            name="workout_type"
            rules={[{ required: true, message: '请输入训练类型' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="组数"
            name="sets"
            rules={[{ required: true, message: '请输入组数' }]}
          >
            <Input type="number" />
          </Form.Item>

          <Form.Item
            label="每组次数"
            name="reps"
            rules={[{ required: true, message: '请输入每组次数' }]}
          >
            <Input type="number" />
          </Form.Item>

          <Form.Item
            label="重量"
            name="weight"
            rules={[{ required: true, message: '请输入重量' }]}
          >
            <Input type="number" />
          </Form.Item>

          <Form.Item
            label="心率"
            name="heart_rate"
            rules={[{ required: true, message: '请输入心率' }]}
          >
            <Input type="number" />
          </Form.Item>

          <Form.Item
            label="燃烧卡路里"
            name="calories_burned"
            rules={[{ required: true, message: '请输入燃烧的卡路里' }]}
          >
            <Input type="number" />
          </Form.Item>

          <Form.Item
  label="是否完成训练目标"
  name="performance"
  initialValue={false}  // 默认未完成
  valuePropName="checked"
>
  <Checkbox>完成训练目标</Checkbox>
</Form.Item>

<Form.Item
  label="训练时长（分）"
  name="duration"
  initialValue={0}  // 默认时长为 0 秒
  rules={[{ required: true, message: '请输入训练时长' }]}
>
  <Input type="number" />
</Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" style={{ width: '100%' }}>
              提交
            </Button>
          </Form.Item>
        </Form>
      </Modal>

{/* 预约课程弹出框 */}
<Modal
  title="预约下次课程"
  visible={isBookingModalVisible}
  onCancel={() => setIsBookingModalVisible(false)}
  footer={null}
  destroyOnClose
>
  <Form
    form={bookingForm}
    onFinish={handleBookSession}
    initialValues={{
      session_date: moment(),
    }}
  >
    <Form.Item
      name="session_date"
      label="预约时间"
      rules={[{ required: true, message: '请选择预约时间' }]}
    >
      <DatePicker
        showTime
        format="YYYY-MM-DD HH:mm"
        style={{ width: '100%' }}
        disabledDate={(current) => current && current < moment().startOf('day')}
      />
    </Form.Item>

    <Form.Item
      name="location"
      label="地点"
      rules={[{ required: true, message: '请输入课程地点' }]}
    >
      <Input placeholder="例如：健身房A区3号房间" />
    </Form.Item>

    <Form.Item>
      <Button 
        type="primary" 
        htmlType="submit" 
        block
        style={{ marginTop: 16 }}
      >
        提交预约
      </Button>
    </Form.Item>
  </Form>
</Modal>

    </div>
  );
};

export default Trainer;