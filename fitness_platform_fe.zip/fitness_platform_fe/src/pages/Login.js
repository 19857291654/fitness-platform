import React, { useState } from 'react';
import { login, register } from '../api';  // 引入登录和注册的API函数
import { useNavigate } from 'react-router-dom';
import { Form, Input, Button, Alert, Spin, Card, notification } from 'antd';  // 引入 Ant Design 组件

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [address, setAddress] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);  // 判断是否在注册
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // 登录功能
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
  
    try {
      const data = await login(email, password);
      console.log(data);  // 打印返回的数据
  
      // 登录成功后，将用户信息和 token 存储到 localStorage
      localStorage.setItem('token', data.token);  // 存储 token
      localStorage.setItem('member', JSON.stringify(data.member));  // 存储会员信息
  
      // 根据角色进行跳转
      if (data.member.role === 'trainer') {
        navigate('/trainer');  // 如果是教练，跳转到教练页面
      } else {
        navigate('/home');  // 如果是会员，跳转到会员主页
      }
    } catch (err) {
      setError(err.message || '登录失败');
    } finally {
      setLoading(false);
    }
  };
  

  // 注册功能
  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
  
    try {
      const data = await register(name, birthDate, address, email, password);
      console.log(data);  // 确保返回的数据是你期望的
  
      // 注册成功后显示等待审核提示
      notification.info({
        message: '注册成功',
        description: '您的账户已注册成功，请等待审核。',
      });
  
      // 存储用户信息和 token
      localStorage.setItem('token', data.token);  // 存储 token
      localStorage.setItem('member', JSON.stringify(data.member));  // 存储会员信息
  
      // 跳转到登录页
      navigate('/login');
    } catch (err) {
      console.error("注册过程中发生错误:", err);  // 输出错误信息
      setError(err.message || '注册失败');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', backgroundColor: '#f0f2f5' }}>
      <Card title={isRegistering ? "注册" : "登录"} style={{ width: 400 }}>
        <Form onSubmitCapture={isRegistering ? handleRegister : handleLogin} layout="vertical">
          {isRegistering && (
            <>
              <Form.Item label="姓名" required>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="请输入姓名"
                  required
                />
              </Form.Item>
              <Form.Item label="生日" required>
                <Input
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  required
                />
              </Form.Item>
              <Form.Item label="地址" required>
                <Input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="请输入地址"
                  required
                />
              </Form.Item>
            </>
          )}
          
          <Form.Item label="邮箱" required>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="请输入邮箱"
              required
            />
          </Form.Item>

          <Form.Item label="密码" required>
            <Input.Password
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="请输入密码"
              required
            />
          </Form.Item>

          {error && <Alert message={error} type="error" showIcon />}

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              block
              disabled={loading}
            >
              {loading ? <Spin size="small" /> : isRegistering ? "注册" : "登录"}
            </Button>
          </Form.Item>

          <Form.Item>
            <Button
              type="link"
              block
              onClick={() => setIsRegistering(!isRegistering)}  // 切换登录/注册
            >
              {isRegistering ? "已有账号？点击登录" : "没有账号？点击注册"}
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default Login;