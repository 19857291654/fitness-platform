// home.js
import React, { useEffect, useState } from 'react';
import { Layout, Menu,Table , Card, Row, Col, Button, Alert, Form, Input, notification } from 'antd';
import { useNavigate } from 'react-router-dom';
import { getMemberTrainingRequests , updateMemberInfo, getTrainers, sendTrainingRequest,bookTrainingSession,getMemberTrainingSessions,cancelTrainingSession,getAllTrainingHistory  } from '../api';
import axios from 'axios';
// 解构 Layout 组件中的子组件
const { Header, Content, Footer, Sider } = Layout;

const Home = () => {
  // 定义状态变量
  const [member, setMember] = useState(null); // 当前会员信息
  const [loading, setLoading] = useState(true); // 加载状态
  const [error, setError] = useState(null); // 错误信息
  const [editing, setEditing] = useState(false); // 是否处于编辑模式
  const [form] = Form.useForm(); // 表单实例
  const [trainers, setTrainers] = useState([]); // 教练列表
  const [searchTerm, setSearchTerm] = useState(''); // 搜索关键词
  const [selectedTrainer, setSelectedTrainer] = useState(null); // 选中的教练
  const [goal, setGoal] = useState(''); // 训练目标
  const [trainingRequests, setTrainingRequests] = useState([]); // 训练预约请求列表
  const [loadingRequests, setLoadingRequests] = useState(false); // 加载状态
  const [isTrainingAccepted, setIsTrainingAccepted] = useState(false); // 标记训练请求是否已被接受
  const [showFormForRequestId, setShowFormForRequestId] = useState(null);
  const [upcomingSessions, setUpcomingSessions] = useState([]); // 存储已预约的课程
  const [loadingUpcomingSessions, setLoadingUpcomingSessions] = useState(false); // 加载状态
  const navigate = useNavigate(); // 路由导航
  const [memberId, setMemberId] = useState(null);
  const [searchParam, setSearchParam] = useState('name');  // 存储下拉框选择的参数（'name' 或 'specialties'）
  const [trainingHistory, setTrainingHistory] = useState([]);
  const token = localStorage.getItem('token'); // 从 localStorage 获取 token
  const storedMember = JSON.parse(localStorage.getItem('member')); // 从 localStorage 获取会员信息

  // 组件挂载时检查用户是否已登录
  useEffect(() => {
    if (!token || !storedMember) {
      navigate('/login'); // 如果没有 token 或者没有存储的会员信息，跳转到登录页面
    } else {
      if (!member) {
        setMember(storedMember); // 设置会员信息
        setLoading(false); // 设置加载状态为 false，表示数据加载完成
      }
    }
  }, [token, storedMember, navigate, member,upcomingSessions]); // 只在 token 或 storedMember 变化时才触发
  
  

  // 搜索教练
  const handleSearchTrainers = async () => {
    try {
      // 根据 searchParam 动态构建查询条件
      const response = await getTrainers(
        searchParam === 'specialties' ? searchTerm : '', 
        searchParam === 'name' ? searchTerm : '', 
        searchParam === 'id' ? searchTerm : ''
      );
      setTrainers(response.trainers || []);  // 设置教练列表
    } catch (error) {
      notification.error({
        message: '搜索失败',
        description: '无法获取教练信息，请稍后重试',
      });
    }
  };

  // 更新会员信息
  const handleUpdate = async (values) => {
    if (!member) return;

    setLoading(true);
    try {
      const updatedMember = await updateMemberInfo(member.id, values); // 调用 API 更新会员信息
      setMember(updatedMember); // 更新状态中的会员信息
      setEditing(false); // 关闭编辑模式
      notification.success({
        message: '更新成功',
        description: '个人信息已成功更新！',
      });
      localStorage.setItem('member', JSON.stringify(updatedMember)); // 更新 localStorage 中的会员信息
    } catch (err) {
      setError('更新失败');
      notification.error({
        message: '更新失败',
        description: err.message || '请稍后重试',
      });
    } finally {
      setLoading(false);
    }
  };

  // 选择教练
  const handleSelectTrainer = (trainerId) => {
    if (!member) {
      notification.error({
        message: '未登录',
        description: '请先登录后选择教练。',
      });
      return;
    }

    const trainer = trainers.find((trainer) => trainer.id === trainerId); // 找到选中的教练
    setSelectedTrainer(trainer); // 设置选中的教练
  };

  // 提交训练目标
    const handleSubmitGoal = async (values) => {
    try {
    const requestData = {
      memberId: member.id,
      trainerId: selectedTrainer.id,
      status: 'pending',
      goal: values.goal,
    };

    // 发送训练请求
    const trainingRequestResponse = await sendTrainingRequest(requestData);
    notification.success({
      message: '训练请求成功',
      description: `您的训练请求已发送给教练 ${selectedTrainer.name}`,
    });

    // 检查训练请求状态是否为 accepted，如果是，显示预约表单
    if (trainingRequestResponse.status === 'accepted') {
      setIsTrainingAccepted(true);  // 更新状态为已接受
      notification.success({
        message: '训练请求已接受',
        description: `教练已接受您的训练请求，您可以继续预约训练。`,
      });
    } else {
      setIsTrainingAccepted(false); // 如果没有接受，则保持未接受状态
    }

    setSelectedTrainer(null); // 清空选中的教练
    setGoal(''); // 清空训练目标
  } catch (error) {
    notification.error({
      message: '请求失败',
      description: error.message || '提交失败，请稍后重试。',
    });
  }
 };
//----------------------------------约课逻辑

  //查看训练预约的逻辑
  const handleViewTrainingRequests = async () => {
    if (!member) {
      notification.error({
        message: '未登录',
        description: '请先登录后查看训练预约。',
      });
      return;
    }
  
    setLoadingRequests(true); // 开始加载
    try {
      const response = await getMemberTrainingRequests(member.id); // 调用接口
      setTrainingRequests(response.trainingRequests || []); // 更新状态
    } catch (error) {
      notification.error({
        message: '加载失败',
        description: '无法获取训练预约，请稍后重试',
      });
    } finally {
      setLoadingRequests(false); // 结束加载
    }
  };

  //你需要创建一个 TrainingSessionForm 组件，包含填写训练session会话的表单：
  const TrainingSessionForm = ({ request, onSubmit }) => {
    const [sessionDate, setSessionDate] = useState('');
    const [location, setLocation] = useState('');
    
    const handleFormSubmit = async () => {
      try {
        // 使用封装好的 API 方法提交数据
        const response = await bookTrainingSession(
          request.trainer_id,
          request.member_id,
          sessionDate,
          location
        );
        
        notification.success({
          message: response.message, // 响应返回的消息
        });
        
        // 调用父组件的回调函数，处理表单提交成功后的操作
        onSubmit(response.trainingSession);
        
      } catch (error) {
        notification.error({
          message: '提交失败',
          description: error.message || '请稍后再试。',
        });
      }
    };
  
    return (
      <Form onFinish={handleFormSubmit}>
        <Form.Item label="训练日期" name="session_date" rules={[{ required: true }]}>
          <Input
            type="datetime-local"
            value={sessionDate}
            onChange={(e) => setSessionDate(e.target.value)}
          />
        </Form.Item>
        
        <Form.Item label="地点" name="location" rules={[{ required: true }]}>
          <Input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </Form.Item>
  
        <Button type="primary" htmlType="submit">提交训练会话</Button>
      </Form>
    );
  };

  // 显示对应accepted请求的表单
  const handleShowForm = (request) => {
    // 只有在当前的 showFormForRequestId 不等于 request.id 时，才更新状态
    if (showFormForRequestId !== request.id) {
      setShowFormForRequestId(request.id);  // 更新状态
    }
  };
  
  

  // 这里可以更新页面或做其他处理
  const handleSubmitTrainingSession = async (values) => {
    const { session_date, location, trainer_id, member_id } = values;
    const payload = { trainer_id, member_id, session_date, location };
  
    try {
      const response = await axios.post('/api/training-sessions', payload);
      notification.success({
        message: response.data.message,
      });
  
      // 只在表单显示时关闭它
      if (showFormForRequestId !== null) {
        setShowFormForRequestId(null); // 提交成功后关闭表单
      }
    } catch (error) {
      notification.error({
        message: '提交失败',
        description: '请稍后再试。',
      });
    }
  };

  const handleViewUpcomingSessions = async () => {
    if (!member) {
      notification.error({
        message: '未登录',
        description: '请先登录后查看训练课程。',
      });
      return;
    }
  
    setLoadingUpcomingSessions(true); // 开始加载
    try {
      // 调用接口获取已预约的课程
      const response = await getMemberTrainingSessions(member.id);
      console.log('接口返回的数据:', response); // 打印接口返回的数据
  
      // 确保返回的数据是一个数组
      const trainingSessions = Array.isArray(response.sessions) ? response.sessions : [];
      console.log('处理后的数据:', trainingSessions); // 打印处理后的数据
  
      // 将数据存储到状态中
      setUpcomingSessions(trainingSessions);
    } catch (error) {
      notification.error({
        message: '加载失败',
        description: '无法获取训练课程，请稍后重试。',
      });
    } finally {
      setLoadingUpcomingSessions(false); // 结束加载
    }
  };

  // 取消课程
  const handleCancelSession = async (sessionId) => {
    try {
      // 调用取消课程的接口
      await cancelTrainingSession(sessionId);
      notification.success({
        message: '取消成功',
        description: '课程已成功取消。',
      });

      // 刷新课程列表
      handleViewUpcomingSessions();
    } catch (error) {
      notification.error({
        message: '取消失败',
        description: error.message || '无法取消课程，请稍后重试。',
      });
    }
  };
  
  {
  Array.isArray(upcomingSessions) && upcomingSessions.length > 0 && (
    <div>
      <h2>即将到来的课程</h2>
      <Row gutter={16}>
        {upcomingSessions.map((session) => (
          <Col key={session.id} span={8}>
            <Card title={`课程ID: ${session.id}`} bordered={false}>
              <p><strong>教练：</strong>{session.Trainer.name}</p>
              <p><strong>时间：</strong>{new Date(session.session_date).toLocaleString()}</p>
              <p><strong>地点：</strong>{session.location}</p>
              <p><strong>状态：</strong>{session.status}</p>
              <p><strong>教练简介：</strong>{session.Trainer.bio}</p>
              <p><strong>教练专长：</strong>{session.Trainer.specialties}</p>
              {/* 添加取消课程按钮 */}
              <Button
                          type="primary"
                          danger
                          style={{ marginTop: 16 }}
                          onClick={() => handleCancelSession(session.id)}
                        >
                          取消课程
                        </Button>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  )
}
// 封装逻辑：调用接口并处理数据
const fetchTrainingHistory = async (memberId) => {
  if (!memberId) {
    notification.error({
      message: '未登录',
      description: '请先登录后查看训练历史。',
    });
    return;
  }

  setLoading(true); // 开始加载
  setError(null);  // 清除之前的错误信息
  
  try {
    // 调用接口获取训练历史数据
    const response = await getAllTrainingHistory(memberId);
    console.log('接口返回的数据:', response); // 打印接口返回的数据

    // 确保返回的数据是一个数组
    const trainingHistory = Array.isArray(response.training_history) ? response.training_history : [];
    console.log('处理后的数据:', trainingHistory); // 打印处理后的数据

    // 将数据存储到状态中
    setTrainingHistory(trainingHistory);
  } catch (err) {
    notification.error({
      message: '加载失败',
      description: '无法获取训练历史，请稍后重试。',
    });
  } finally {
    setLoading(false); // 结束加载
  }
};


// 定义表格列
const columns = [
  {
    title: '训练类型',
    dataIndex: 'workout_type',
    key: 'workout_type',
  },
  {
    title: '组数',
    dataIndex: 'sets',
    key: 'sets',
  },
  {
    title: '重复次数',
    dataIndex: 'reps',
    key: 'reps',
  },
  {
    title: '重量 (kg)',
    dataIndex: 'weight',
    key: 'weight',
  },
  {
    title: '心率',
    dataIndex: 'heart_rate',
    key: 'heart_rate',
  },
  {
    title: '卡路里消耗',
    dataIndex: 'calories_burned',
    key: 'calories_burned',
  },
  {
    title: '时长 (分钟)',
    dataIndex: 'duration',
    key: 'duration',
  },
  {
    title: '教练',
    dataIndex: 'Trainer',
    key: 'Trainer',
    render: (text) => text.name, // 显示教练名字
  },
];
//----------------------------------------
  // 路由导航函数
  const navigateTo = (path) => navigate(path);

  // 加载中或错误时的显示
  if (loading) return <div>加载中...</div>;
  if (error) return <div>{error}</div>;

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header style={{ background: '#fff', padding: '0 20px', boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' }}>
        {/* 标题 */}
        <div style={{ float: 'left', fontSize: '20px', fontWeight: 'bold', color: '#333' }}>
          教练预约系统
        </div>
        {/* 退出登录按钮 */}
        <Button
          type="link"
          onClick={() => navigateTo('/login')}
          style={{
            float: 'right',
            marginRight: 20,
            fontSize: '16px',
            color: '#1890ff',
            transition: 'color 0.3s',
            fontWeight: 'bold',
          }}
          onMouseEnter={(e) => e.target.style.color = '#40a9ff'}
          onMouseLeave={(e) => e.target.style.color = '#1890ff'}
        >
          退出
        </Button>
      </Header>
  
      <Layout>
  {/* ==================== 侧边栏导航 ==================== */}
  <Sider width={200} className="site-layout-background">
    <Menu 
      mode="inline" 
      defaultSelectedKeys={['1']} 
      style={{ height: '100%', borderRight: 0 }}
    >
      <Menu.Item key="1" onClick={() => navigateTo('/home')}>主页</Menu.Item>
      <Menu.Item key="2" onClick={() => navigateTo('/training-sessions')}>训练预约</Menu.Item>
      <Menu.Item key="3" onClick={() => navigateTo('/training-history')}>训练历史</Menu.Item>
      <Menu.Item key="4" onClick={() => setEditing(true)}>更新资料</Menu.Item>
      <Menu.Item key="5" onClick={() => navigateTo('/profile')}>我的资料</Menu.Item>
    </Menu>
  </Sider>

  <Layout style={{ padding: '0 24px 24px' }}>
    <Content style={{ padding: 24, margin: 0, minHeight: 280 }}>
      
      {/* ================ 用户信息展示区块 ================ */}
      <section className="user-info-section">
        <Row gutter={16}>
          <Col span={24}>
            <Card title={`欢迎回来，${member.name}`} bordered={false}>
              <p><strong>电子邮件：</strong>{member.email}</p>
              <p><strong>生日：</strong>{member.birth_date}</p>
              <p><strong>地址：</strong>{member.address}</p>
            </Card>
          </Col>
        </Row>
      </section>

      {/* ============== 功能模块快速入口区块 ============== */}
      <section className="quick-access-section">
        <h2>我的功能模块</h2>
        <Row gutter={16}>
          <Col span={6}>
            <Card title="训练预约" bordered={false}>
              <Button type="primary" onClick={handleViewTrainingRequests}>
                查看训练预约
              </Button>
            </Card>
          </Col>
          <Col span={6}>
            <Card title="训练课程" bordered={false}>
              <Button type="primary" onClick={handleViewUpcomingSessions}>
                查看即将到来的课程
              </Button>
            </Card>
          </Col>
          <Col span={6}>
            <Card title="训练历史" bordered={false}>
              <Button type="primary" onClick={() => fetchTrainingHistory(member.id)} loading={loading}>
                查看训练历史
              </Button>
            </Card>
          </Col>
          <Col span={6}>
            <Card title="更新资料" bordered={false}>
              <Button type="primary" onClick={() => setEditing(true)}>
                更新个人信息
              </Button>
            </Card>
          </Col>
        </Row>
      </section>

      {/* ============== 教练搜索与预约区块 ============== */}
      <section className="coach-section">
        <h2>搜索私人教练</h2>
        <Row gutter={16}>
  <Col span={12}>
    {/* 下拉框选择搜索参数 */}
    <select
      onChange={(e) => setSearchParam(e.target.value)}
      value={searchParam}
      style={{
        width: '100%',
        padding: '8px',
        borderRadius: '8px',  // 给下拉框添加圆角
        border: '1px solid #d9d9d9',  // 可选：添加边框
        fontSize: '14px'  // 可选：调整字体大小
      }}
    >
      <option value="name">根据教练名称搜索</option>
      <option value="specialties">根据擅长领域搜索</option>
      <option value="id">根据教练id搜索</option>
    </select>
  </Col>

  <Col span={12}>
    {/* 输入框，根据选择的条件进行输入 */}
    <Input.Search
      placeholder={`输入${searchParam === 'name' ? '教练名称' : (searchParam === 'specialties' ? '擅长领域' : '教练id')}`}
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
      onSearch={handleSearchTrainers}
      enterButton="搜索"
      style={{
        width: '100%',
        padding: '8px',
        borderRadius: '8px',  // 给搜索框添加圆角
        border: '1px solid #d9d9d9',  // 可选：添加边框
        fontSize: '14px'  // 可选：调整字体大小
      }}
    />
  </Col>
</Row>


        {/* 教练列表展示 */}
        <Row gutter={16}>
          {trainers.length > 0 ? (
            trainers.map((trainer) => (
              <Col key={trainer.id} span={8}>
                <Card title={trainer.name} bordered={false}>
                  <p><strong>擅长：</strong>{trainer.specialties}</p>
                  <p><strong>简介：</strong>{trainer.bio}</p>
                  <Button type="primary" onClick={() => handleSelectTrainer(trainer.id)}>
                    选择该教练
                  </Button>
                </Card>
              </Col>
            ))
          ) : (
            <Col span={24}>
              <p>没有找到符合条件的教练</p>
            </Col>
          )}
        </Row>

        {/* 训练目标表单 */}
        {selectedTrainer && !isTrainingAccepted && (
          <div className="training-goal-form">
            <h3>向教练 {selectedTrainer.name} 描述训练目标</h3>
            <Form onFinish={handleSubmitGoal}>
              <Form.Item
                label="训练目标"
                name="goal"
                rules={[{ required: true, message: '请输入您的训练目标' }]}
              >
                <Input
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="例如：增肌"
                />
              </Form.Item>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交训练请求
              </Button>
              <Button style={{ marginLeft: 10 }} onClick={() => setSelectedTrainer(null)}>
                取消
              </Button>
            </Form>
          </div>
        )}
      </section>

      {/* ================ 动态内容展示区块 ================ */}
      <section className="dynamic-content-section">
        {/* 训练历史记录 */}
        <h2>训练历史记录</h2>
        <Table
          columns={columns}
          dataSource={trainingHistory}
          rowKey="id"
          pagination={false}
        />

        {/* 更新个人信息表单 */}
        {editing && (
          <div className="profile-edit-form">
            <h2>更新个人信息</h2>
            <Form form={form} onFinish={handleUpdate} initialValues={member}>
              <Form.Item label="姓名" name="name" rules={[{ required: true, message: '请输入您的姓名' }]}>
                <Input />
              </Form.Item>
              <Form.Item label="生日" name="birth_date" rules={[{ required: true, message: '请输入您的生日' }]}>
                <Input />
              </Form.Item>
              <Form.Item label="地址" name="address" rules={[{ required: true, message: '请输入您的地址' }]}>
                <Input />
              </Form.Item>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交更新
              </Button>
              <Button style={{ marginLeft: 10 }} onClick={() => setEditing(false)}>
                取消
              </Button>
            </Form>
          </div>
        )}

        {/* 系统通知 */}
        <h2>系统通知</h2>
        <Alert
          message="新课程预约提醒"
          description="您的私人教练已添加新课程，请查看并确认预约。"
          type="info"
          showIcon
        />

            {/* 点击查看训练预约后显示的训练请求列表 */}
            {trainingRequests.length > 0 && (
              <Row gutter={16}>
              {trainingRequests.map((request) => (
                <Col key={request.id} span={8}>
                  <Card title={`预约编号: ${request.id}`} bordered={false}>
                    <p>
                    <strong>状态：</strong>
                    {request.status === 'pending'
                     ? '等待处理中'
                     : request.status === 'accepted'
                     ? '已被接受，请预约课程'
                     : request.status === 'suggested'
                     ? `推荐其他教练 (教练 ID: ${request.recommended_trainer_id})`
                     : request.status}
                    </p>
                    <p><strong>目标：</strong>{request.goal || '无目标'}</p>
                    <p><strong>创建时间：</strong>{new Date(request.created_at).toLocaleString()}</p>
            
                    {/* 如果状态是 'accepted'，显示按钮 */}
                    {request.status === 'accepted' && (
                      <Button onClick={() => handleShowForm(request)} type="primary">
                        预约时间和地点
                      </Button>
                    )}
                  </Card>
            
                  {/* 如果当前正在填写训练会话表单，渲染表单 */}
                  {showFormForRequestId === request.id && (
                    <TrainingSessionForm request={request} onSubmit={handleSubmitTrainingSession} />
                  )}
                </Col>
              ))}
            </Row>
            )}

        {/* 即将到来的课程 */}
  {
  Array.isArray(upcomingSessions) && upcomingSessions.length > 0 && (
    <div>
      <h2>即将到来的课程</h2>
      <Row gutter={16}>
        {upcomingSessions.map((session) => (
          <Col key={session.id} span={8}>
            <Card title={`课程ID: ${session.id}`} bordered={false}>
              <p><strong>教练：</strong>{session.Trainer.name}</p>
              <p><strong>时间：</strong>{new Date(session.session_date).toLocaleString()}</p>
              <p><strong>地点：</strong>{session.location}</p>
              <p><strong>状态：</strong>{session.status}</p>
              <p><strong>教练简介：</strong>{session.Trainer.bio}</p>
              <p><strong>教练专长：</strong>{session.Trainer.specialties}</p>
              {/* 添加取消课程按钮 */}
              <Button
                          type="primary"
                          danger
                          style={{ marginTop: 16 }}
                          onClick={() => handleCancelSession(session.id)}
                        >
                          取消课程
                        </Button>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
        )}
      </section>
    </Content>
  </Layout>
</Layout>
  
      {/* 页脚 */}
      <Footer style={{ textAlign: 'center' }}>
        Fitness Platform ©2025 Created by YourCompany
      </Footer>
    </Layout>
  );
  
}
export default Home;