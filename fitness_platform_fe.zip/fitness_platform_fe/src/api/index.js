import axios from 'axios';

// 设置默认的 API 请求地址（可以根据实际情况修改）
const api = axios.create({
  baseURL: 'http://localhost:5000/api', // 你的后端地址
  timeout: 5000,  // 请求超时
});

// 登录请求
export const login = async (email, password) => {
  try {
    const response = await api.post('/members/login', { email, password });
    return response.data; // 返回响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 会员注册
export const register = async (name, birth_date, address, email, password) => {
  try {
    const response = await api.post('/members/register', { name, birth_date, address, email, password });
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取会员信息
export const getMemberInfo = async (memberId) => {
  try {
    const response = await api.get(`/members/${memberId}`);
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 更新会员信息
export const updateMemberInfo = async (memberId, updatedInfo) => {
  try {
    const response = await api.put(`/members/${memberId}`, updatedInfo);
    return response.data;  // 返回更新后的数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取所有会员数据
export const getAllMembers = async () => {
  try {
    const response = await api.get('/members');
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 审批会员
export const approveMember = async (id) => {
  try {
    const response = await api.put(`/members/approve/${id}`);
    return response.data;  // 返回响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取私人教练信息
export const getTrainers = async (specialties, name, id) => {
  try {
    const params = {};

    // 如果 specialties 存在，添加到查询参数
    if (specialties) {
      params.specialties = specialties;
    }

    // 如果 name 存在，添加到查询参数
    if (name) {
      params.name = name;
    }

    // 如果 id 存在，添加到查询参数
    if (id) {
      params.id = id;
    }

    const response = await api.get('/trainers', { params });
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};


// 向私人教练发送训练请求
export const sendTrainingRequest = async (requestData) => {
  try {
    const response = await api.post('/training-requests', requestData);  // 使用 api 实例发送请求
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取所有训练请求
export const getAllTrainingRequests = async () => {
  try {
    const response = await api.get('/training-requests');
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 响应训练请求
export const respondToTrainingRequest = async (id, response) => {
  try {
    const responseData = await api.put(`/training-requests/response/${id}`, { response });
    return responseData.data;  // 返回响应的数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取特定会员的训练请求
export const getMemberTrainingRequests = async (memberId) => {
  try {
    const response = await api.get(`/training-requests/member/${memberId}`);
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 预约训练发送到session表里面去
export const bookTrainingSession = async (trainer_id, member_id, session_date, location) => {
  try {
    const response = await api.post('/training-sessions', {
      trainer_id,
      member_id,
      session_date,
      location,
    });
    return response.data; // 返回响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取特定会员的训练会话数据
export const getMemberTrainingSessions = async (memberId) => {
  try {
    const response = await api.get(`/training-sessions/member/${memberId}`);
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 取消课程的接口
export const cancelTrainingSession = async (sessionId) => {
  try {
    const response = await api.delete(`/training-sessions/${sessionId}`);
    return response.data; // 返回接口响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取所有课程信息
export const getAllTrainingSessions = async () => {
  try {
    const response = await api.get('/training-sessions');
    return response.data; // 返回接口响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 上课接口，传入训练历史信息
export const recordTrainingHistory = async (history) => {
  try {
    const response = await api.post('/training-history', history);
    return response.data; // 返回接口响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 获取用户的训练历史
export const getAllTrainingHistory = async (memberId) => {
  try {
    const response = await api.get(`/training-history/member/${memberId}`);
    return response.data; // 返回接口响应数据
  } catch (error) {
    throw error.response ? error.response.data : error.message;
  }
};

// 推荐其他教练的请求方法
export const recommendTrainer = async (trainingRequestId, recommendedTrainerId) => {
  try {
    const response = await api.put(`/training-requests/recommend-trainer/${trainingRequestId}`, {
      recommended_trainer_id: recommendedTrainerId
    });
    return response.data;  // 返回响应数据，可以用于更新 UI
  } catch (error) {
    console.error('Error recommending trainer:', error);
    throw error;  // 抛出错误，供调用方捕获
  }
};

// 教练修改上课状态为已完成
export const completeSession = async (sessionId) => {
  try {
    const response = await api.put(`/training-sessions/complete/${sessionId}`);
    return response.data;  // 返回响应数据，可以用于更新 UI
  } catch (error) {
    console.error('Error completing session:', error.response?.data?.message || error.message);
    throw error;  // 抛出错误，供调用方捕获
  }
};
