// controllers/memberController.js
const MemberService = require('../services/memberService');
const argon2 = require('argon2'); // 使用 argon2 进行密码加密
const jwt = require('jsonwebtoken'); // 引入 jsonwebtoken
const Member = require('../models/member');
// 会员注册
exports.register = async (req, res) => {
  try {
    const { name, birth_date, address, email, password } = req.body;

    // 确保密码是字符串且不为空
    if (typeof password !== 'string' || password.trim() === '') {
      return res.status(400).json({ message: 'Password must be a non-empty string' });
    }

    // 调用 MemberService 注册会员
    const newMember = await MemberService.registerMember({ name, birth_date, address, email, password });
    res.status(201).json({ message: 'Member registered successfully', member: newMember });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// 获取会员信息
exports.getMemberInfo = async (req, res) => {
  try {
    const memberId = req.params.id;
    const member = await MemberService.getMemberInfo(memberId);
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }
    res.status(200).json(member);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// 更新会员信息
exports.updateMemberInfo = async (req, res) => {
  try {
    const memberId = req.params.id;
    const updatedInfo = req.body;
    const updatedMember = await MemberService.updateMemberInfo(memberId, updatedInfo);
    res.status(200).json(updatedMember);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// 审批会员
exports.approveMember = async (req, res) => {
  try {
    const memberId = req.params.id;
    await MemberService.approveMember(memberId);
    res.status(200).json({ message: 'Member approved successfully' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// 会员登录
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    // 从 MemberService 获取会员信息
    const member = await MemberService.getMemberByEmail(email);
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }

    // 判断是否通过审核
    if (member.approved === false) { 
      return res.status(403).json({
        message: '您的账户正在等待审核，请等待管理员审核。'
      });
    }

    // 验证密码
    const isPasswordValid = await argon2.verify(member.password, password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // 生成 JWT token
    const token = jwt.sign({ id: member.id, role: member.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // 返回 token 和用户信息
    res.status(200).json({
      message: 'Login successful',
      token,
      member: {
        id: member.id,
        name: member.name,
        email: member.email,
        birth_date: member.birth_date,
        address: member.address,
        approved: member.approved,
        role: member.role  // 返回 role 字段
      },
    });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// 获取所有会员数据
exports.getAllMembers = async (req, res) => {
  try {
    const members = await Member.findAll();  // 这里应该是 Member 而不是 members
    return res.status(200).json({
      message: 'All members retrieved successfully',
      members
    });
  } catch (error) {
    console.error('Error fetching members:', error);
    return res.status(500).json({ message: 'Error fetching members' });
  }
};
