// controllers/trainingHistoryController.js
const  TrainingHistory  = require('../models/trainingHistory');
const TrainingSession = require('../models/trainingSession');
const   Member   = require('../models/member');
const  Trainer = require('../models/trainer');
//用来更新或创建会员的训练历史记录。接收请求体，更新 TrainingHistory 数据表。
exports.createTrainingHistory = async (req, res) => {
  const { member_id, trainer_id, session_id, workout_type, sets, reps, weight, heart_rate, calories_burned, performance, duration } = req.body;

  try {
    // 验证会员、教练和训练会话是否存在
    const member = await Member.findByPk(member_id);
    const trainer = await Trainer.findByPk(trainer_id);
    const session = await TrainingSession.findByPk(session_id);

    if (!member || !trainer || !session) {
      return res.status(404).json({ message: 'Invalid member, trainer, or session ID' });
    }

    // 创建训练历史记录
    const trainingHistory = await TrainingHistory.create({
      member_id,
      trainer_id,
      session_id,
      workout_type,
      sets,
      reps,
      weight,
      heart_rate,
      calories_burned,
      performance,  // 新的字段
      duration,     // 新的字段
    });

    return res.status(201).json({
      message: 'Training progress updated successfully',
      data: trainingHistory,
    });
  } catch (error) {
    console.error('Error creating training history:', error);
    return res.status(500).json({ message: error.message });
  }
};

//获取会员的训练历史记录，基于会员 ID 查找。
exports.getMemberTrainingHistory = async (req, res) => {
  const { memberId } = req.params;

  try {
    const trainingHistory = await TrainingHistory.findAll({
      where: { member_id: memberId },
      include: [
        { model: TrainingSession },  // 直接包含 TrainingSession
        { model: Trainer },  // 直接包含 Trainer
      ],
    });

    if (!trainingHistory || trainingHistory.length === 0) {
      return res.status(404).json({ message: 'No training history found for this member' });
    }

    return res.status(200).json({
      training_history: trainingHistory,
    });
  } catch (error) {
    console.error("Error fetching member's training history:", error);
    return res.status(500).json({ message: error.message });
  }
};

  //获取教练指导的所有会员的训练历史记录，基于教练 ID 查找。
  exports.getCoachTrainingHistory = async (req, res) => {
    const { coachId } = req.params;
  
    try {
      const trainingHistory = await TrainingHistory.findAll({
        where: { trainer_id: coachId },
        include: [
          { model: Member },  // 直接关联 Member
          { model: TrainingSession },  // 直接关联 TrainingSession
        ],
      });
  
      if (!trainingHistory || trainingHistory.length === 0) {
        return res.status(404).json({ message: 'No training history found for this coach' });
      }
  
      return res.status(200).json({
        training_history: trainingHistory,
      });
    } catch (error) {
      console.error("Error fetching coach's training history:", error);
      return res.status(500).json({ message: error.message });
    }
  };
  