// controllers/trainingRequestController.js
const  TrainingRequest  = require('../models/trainingRequest');
const   Member   = require('../models/member');
const  Trainer = require('../models/trainer');

exports.createTrainingRequest = async (req, res) => {
  console.log(req.body);  // 检查请求体中的内容
  const { memberId, trainerId, goal, status } = req.body;

  try {
    const member = await Member.findByPk(memberId);
    const trainer = await Trainer.findByPk(trainerId);

    if (!member || !trainer) {
      return res.status(404).json({ message: 'Member or Trainer not found' });
    }


    const trainingRequest = await TrainingRequest.create({
      member_id: memberId,  
      trainer_id: trainerId,
      goal,
      status: status || 'pending',
    });

    return res.status(201).json({
      message: 'Training request created successfully',
      trainingRequest
    });
  } catch (error) {
    console.error('Error creating training request:', error);
    return res.status(400).json({ message: error.message });
  }
};

//获取某个训练请求的详情
exports.getTrainingRequest = async (req, res) => {
    const { id } = req.params;
  
    try {
      const trainingRequest = await TrainingRequest.findByPk(id);
  
      if (!trainingRequest) {
        return res.status(404).json({ message: 'Training request not found' });
      }
  
      return res.status(200).json({
        message: 'Training request details',
        trainingRequest
      });
    } catch (error) {
      console.error('Error getting training request:', error);
      return res.status(400).json({ message: error.message });
    }
  };
//获取会员所有的训练请求。
  exports.getMemberTrainingRequests = async (req, res) => {
    const { member_id  } = req.params;
  
    try {
      const trainingRequests = await TrainingRequest.findAll({
        where: { member_id  }
      });
  
      return res.status(200).json({
        message: 'Member training requests',
        trainingRequests
      });
    } catch (error) {
      console.error('Error getting member\'s training requests:', error);
      return res.status(400).json({ message: error.message });
    }
  };
  // 教练响应训练请求
  exports.coachResponse = async (req, res) => {
    const { id } = req.params;
    const { response, recommended_trainer_id } = req.body;
  
    try {
      // 查找训练请求
      const trainingRequest = await TrainingRequest.findByPk(id);
  
      if (!trainingRequest) {
        return res.status(404).json({ message: 'Training request not found' });
      }
  
      // 更新训练请求的状态和教练信息
      let updatedStatus = '';
      if (response === 'accept') {
        updatedStatus = 'accepted';
        trainingRequest.trainer_id = trainingRequest.trainer_id;  // 保持当前教练
      } else if (response === 'reject') {
        updatedStatus = 'rejected';
      } else if (response === 'suggest') {
        // 处理建议的情况
        if (!recommended_trainer_id) {
          return res.status(400).json({ message: 'Recommended trainer ID is required for suggestion' });
        }
        
        // 通过推荐的教练ID查找推荐的教练
        const recommendedTrainer = await Trainer.findByPk(recommended_trainer_id);
        if (!recommendedTrainer) {
          return res.status(404).json({ message: 'Recommended trainer not found' });
        }
  
        // 更新请求状态为建议状态
        updatedStatus = 'suggested';
        
        // 更新教练信息为推荐的教练
        trainingRequest.trainer_id = recommended_trainer_id;  // 将推荐的教练ID更新到 trainer_id
        trainingRequest.recommended_trainer_id = recommended_trainer_id;  // 保留推荐的教练ID
  
      } else {
        return res.status(400).json({ message: 'Invalid response value' });
      }
  
      // 更新训练请求的状态
      trainingRequest.status = updatedStatus;
      
      // 保存更新后的请求
      await trainingRequest.save();
  
      return res.status(200).json({ message: 'Trainer responded to the request' });
    } catch (error) {
      console.error('Error responding to training request:', error);
      return res.status(500).json({ message: error.message });
    }
  };
  

// 获取教练所有的训练请求
exports.getCoachTrainingRequests = async (req, res) => {
  const { coachId } = req.params;  // 获取教练ID

  try {
    const trainingRequests = await TrainingRequest.findAll({
      where: {
        trainer_id: coachId  // 查找教练的所有训练请求
      }
    });

    return res.status(200).json({
      requests: trainingRequests
    });
  } catch (error) {
    console.error('Error getting coach training requests:', error);
    return res.status(400).json({ message: error.message });
  }
};

// 获取所有训练请求
exports.getAllTrainingRequests = async (req, res) => {
  try {
    const trainingRequests = await TrainingRequest.findAll();  // 获取所有训练请求
    return res.status(200).json({
      message: 'All training requests',
      trainingRequests
    });
  } catch (error) {
    console.error('Error getting all training requests:', error);
    return res.status(400).json({ message: error.message });
  }
};

// 教练推荐其他教练
exports.recommendOtherTrainer = async (req, res) => {
  const { id } = req.params;
  const { recommended_trainer_id } = req.body;

  try {
    // 查找训练请求
    const trainingRequest = await TrainingRequest.findByPk(id);

    if (!trainingRequest) {
      return res.status(404).json({ message: 'Training request not found' });
    }

    // 查找推荐的教练
    const recommendedTrainer = await Trainer.findByPk(recommended_trainer_id);
    if (!recommendedTrainer) {
      return res.status(404).json({ message: 'Recommended trainer not found' });
    }

    // 更新训练请求中的推荐教练信息
    trainingRequest.recommended_trainer_id = recommended_trainer_id;
    trainingRequest.status = 'suggested';  // 状态设为已推荐

    // 保存更新后的训练请求
    await trainingRequest.save();

    return res.status(200).json({
      message: 'Successfully recommended a new trainer',
      trainingRequest
    });
  } catch (error) {
    console.error('Error recommending trainer:', error);
    return res.status(500).json({ message: error.message });
  }
};