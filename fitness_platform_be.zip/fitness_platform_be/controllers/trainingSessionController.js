// controllers/trainingSessionController.js
const TrainingSession = require('../models/trainingSession');
const  Trainer = require('../models/trainer');
//预订课程
exports.bookTrainingSession = async (req, res) => {
  const { trainer_id, member_id, session_date, location } = req.body;

  try {
    // 创建课程预订记录
    const trainingSession = await TrainingSession.create({
      trainer_id,
      member_id,
      session_date,
      location,
    });

    return res.status(201).json({
      message: 'Training session booked successfully',
      trainingSession,
    });
  } catch (error) {
    console.error('Error booking training session:', error);
    return res.status(500).json({ message: error.message });
  }
};
//获取会员的课程预订记录
exports.getMemberTrainingSessions = async (req, res) => {
  const { memberId } = req.params;

  try {
    const trainingSessions = await TrainingSession.findAll({
      where: { member_id: memberId },
      include: [
        {
          model: Trainer,
          as: 'Trainer',  // 这里的 'Trainer' 需要与关联定义的默认别名一致
        },
      ],
    });

    return res.status(200).json({
      sessions: trainingSessions,
    });
  } catch (error) {
    console.error("Error fetching member's training sessions:", error);
    return res.status(500).json({ message: error.message });
  }
};

  //取消课程
  exports.cancelTrainingSession = async (req, res) => {
    const { id } = req.params;
  
    try {
      const trainingSession = await TrainingSession.findByPk(id);
  
      if (!trainingSession) {
        return res.status(404).json({ message: 'Training session not found' });
      }
  
      // 更新课程状态为已取消
      trainingSession.status = 'Cancelled';
      await trainingSession.save();
  
      return res.status(200).json({
        message: 'Training session canceled successfully',
      });
    } catch (error) {
      console.error('Error canceling training session:', error);
      return res.status(500).json({ message: error.message });
    }
  };

  // 查看即将到来的训练预约
exports.getUpcomingTrainingSessions = async (req, res) => {
  const { memberId } = req.params;

  try {
    const upcomingSessions = await TrainingSession.findAll({
      where: {
        member_id: memberId,
        session_date: { 
          [Sequelize.Op.gt]: new Date()  // 过滤未来的课程
        }
      },
      include: [
        { model: Trainer },
      ],
    });

    if (!upcomingSessions || upcomingSessions.length === 0) {
      return res.status(404).json({ message: 'No upcoming sessions found for this member' });
    }

    return res.status(200).json({
      upcoming_sessions: upcomingSessions.map(session => ({
        id: session.id,
        trainer_id: session.trainer_id,
        session_time: session.session_date,
        location: session.location,
      })),
    });
  } catch (error) {
    console.error("Error fetching upcoming training sessions:", error);
    return res.status(500).json({ message: error.message });
  }
};

// 取消即将到来的训练预约
exports.cancelTrainingSession = async (req, res) => {
  const { id } = req.params;

  try {
    const session = await TrainingSession.findOne({ where: { id } });

    if (!session) {
      return res.status(404).json({ message: 'Training session not found' });
    }

    // 检查课程是否是未来的课程
    if (new Date(session.session_date) < new Date()) {
      return res.status(400).json({ message: 'Cannot cancel past sessions' });
    }

    await session.destroy(); // 删除训练预约

    return res.status(200).json({ message: 'Session canceled successfully' });
  } catch (error) {
    console.error("Error canceling training session:", error);
    return res.status(500).json({ message: error.message });
  }
};

// 查看训练课程的完整历史记录
exports.getTrainingHistory = async (req, res) => {
  const { memberId } = req.params;

  try {
    const trainingHistory = await TrainingSession.findAll({
      where: {
        member_id: memberId,
        session_date: { 
          [Sequelize.Op.lt]: new Date()  // 过滤过去的课程
        }
      },
      include: [
        { model: Trainer },
      ],
    });

    if (!trainingHistory || trainingHistory.length === 0) {
      return res.status(404).json({ message: 'No training history found for this member' });
    }

    return res.status(200).json({
      history: trainingHistory.map(session => ({
        session_id: session.id,
        trainer_id: session.trainer_id,
        session_time: session.session_date,
        location: session.location,
        status: session.status, // 根据实际状态字段可能为 completed/cancelled
      })),
    });
  } catch (error) {
    console.error("Error fetching training history:", error);
    return res.status(500).json({ message: error.message });
  }
};

// 查看上周或上个月的总锻炼小时数
exports.getTotalTrainingHours = async (req, res) => {
  const { memberId } = req.params;

  try {
    const { period } = req.query; // period 可以是 'week' 或 'month'

    // 计算开始和结束日期
    let startDate, endDate;
    if (period === 'week') {
      startDate = moment().subtract(1, 'week').startOf('week').toDate();
      endDate = moment().subtract(1, 'week').endOf('week').toDate();
    } else if (period === 'month') {
      startDate = moment().subtract(1, 'month').startOf('month').toDate();
      endDate = moment().subtract(1, 'month').endOf('month').toDate();
    } else {
      return res.status(400).json({ message: 'Invalid period. Use "week" or "month".' });
    }

    const sessions = await TrainingSession.findAll({
      where: {
        member_id: memberId,
        session_date: { 
          [Sequelize.Op.gte]: startDate,
          [Sequelize.Op.lte]: endDate,
        },
      },
    });

    if (!sessions || sessions.length === 0) {
      return res.status(404).json({ message: 'No sessions found for the given period' });
    }

    // 计算总小时数
    const totalHours = sessions.reduce((total, session) => {
      const duration = moment(session.session_date).diff(moment(session.end_time), 'hours');
      return total + duration;
    }, 0);

    return res.status(200).json({
      total_hours: totalHours,
    });
  } catch (error) {
    console.error("Error fetching total training hours:", error);
    return res.status(500).json({ message: error.message });
  }
};

// 获取所有课程信息
exports.getAllTrainingSessions = async (req, res) => {
  try {
    // 查询所有课程，并关联教练信息
    const trainingSessions = await TrainingSession.findAll({
      include: [
        {
          model: Trainer,
          as: 'Trainer', // 确保与关联定义的别名一致
        },
      ],
    });

    // 如果没有任何课程，返回空数组
    if (!trainingSessions || trainingSessions.length === 0) {
      return res.status(200).json({ sessions: [] });
    }

    // 返回所有课程信息
    return res.status(200).json({
      sessions: trainingSessions.map((session) => ({
        id: session.id,
        trainer_id: session.trainer_id,
        member_id: session.member_id,
        session_date: session.session_date,
        location: session.location,
        status: session.status,
        created_at: session.created_at,
        updated_at: session.updated_at,
        Trainer: session.Trainer ? {
          id: session.Trainer.id,
          name: session.Trainer.name,
          bio: session.Trainer.bio,
          specialties: session.Trainer.specialties,
          email: session.Trainer.email,
        } : null,
      })),
    });
  } catch (error) {
    console.error('Error fetching all training sessions:', error);
    return res.status(500).json({ message: error.message });
  }
};

// 修改课程状态为已上课
exports.updateTrainingSessionStatus = async (req, res) => {
  const { id } = req.params;

  try {
    const session = await TrainingSession.findByPk(id);

    if (!session) {
      return res.status(404).json({ message: 'Training session not found' });
    }

    // 确保课程尚未标记为已上课或已取消
    if (session.status === 'Completed') {
      return res.status(400).json({ message: 'Training session has already been completed' });
    }

    // 更新课程状态为已上课
    session.status = 'Completed';
    await session.save();

    return res.status(200).json({
      message: 'Training session marked as completed successfully',
      session,
    });
  } catch (error) {
    console.error('Error updating training session status:', error);
    return res.status(500).json({ message: error.message });
  }
};
