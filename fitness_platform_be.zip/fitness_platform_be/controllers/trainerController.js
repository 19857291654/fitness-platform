// controllers/trainerController.js
const Trainer  = require('../models/trainer');
const { Op } = require('sequelize');  // 导入 Sequelize 的操作符

exports.searchTrainers = async (req, res) => {
  try {
    const { specialties, name , id } = req.query;
    const where = {};

    if (specialties) {
      where.specialties = { [Op.like]: `%${specialties}%` };  // 使用模糊查询
    }

    if (name) {
      where.name = { [Op.like]: `%${name}%` };  // 使用模糊查询
    }
    if (id) {
      where.id = id;  // 精确匹配 id
    }

    const trainers = await Trainer.findAll({ where });

    return res.status(200).json({
      message: 'Trainers found successfully',
      trainers
    });
  } catch (error) {
    console.error('Error searching trainers:', error);
    return res.status(400).json({ message: error.message });
  }
};
