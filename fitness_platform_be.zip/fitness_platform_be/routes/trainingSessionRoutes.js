// routes/trainingSessionRoutes.js
const express = require('express');
const {
  bookTrainingSession,
  getMemberTrainingSessions,
  cancelTrainingSession,
  getUpcomingTrainingSessions,
  getTrainingHistory,
  getTotalTrainingHours,
  getAllTrainingSessions,
  updateTrainingSessionStatus,
} = require('../controllers/trainingSessionController');
const router = express.Router();

// 获取所有课程信息
router.get('/training-sessions', getAllTrainingSessions); // 添加新路由


// 会员预订课程
router.post('/training-sessions', bookTrainingSession);

// 获取会员所有的课程预订
router.get('/training-sessions/member/:memberId', getMemberTrainingSessions);

// 取消课程
router.delete('/training-sessions/:id', cancelTrainingSession);

// 查看即将到来的训练预约
router.get('/training-sessions/upcoming/member/:memberId', getUpcomingTrainingSessions);

// 取消即将到来的训练预约
router.delete('/training-sessions/cancel/:id', cancelTrainingSession);

// 查看训练课程的完整历史记录
router.get('/training-sessions/history/member/:memberId', getTrainingHistory);

// 查看上周或上个月的总锻炼小时数
router.get('/training-sessions/total-hours/member/:memberId', getTotalTrainingHours);

// 修改课程状态为已上课
router.put('/training-sessions/complete/:id', updateTrainingSessionStatus);


module.exports = router;
