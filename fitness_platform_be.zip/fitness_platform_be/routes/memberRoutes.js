const express = require('express');
const router = express.Router();
const memberController = require('../controllers/memberController');
// 会员注册
router.post('/register', memberController.register);

// 获取会员信息
router.get('/:id', memberController.getMemberInfo);

// 更新会员信息
router.put('/:id', memberController.updateMemberInfo);

// 审批会员
router.put('/approve/:id', memberController.approveMember);

// 会员登录
router.post('/login', memberController.login);  // 添加的登录接口

// 获取所有会员
router.get('/', memberController.getAllMembers);

module.exports = router;
