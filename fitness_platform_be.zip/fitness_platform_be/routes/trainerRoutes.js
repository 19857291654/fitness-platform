// routes/trainerRoutes.js
const express = require('express');
const { searchTrainers } = require('../controllers/trainerController');
const router = express.Router();

// 搜索私人教练
router.get('/trainers', searchTrainers);

module.exports = router;
