const express = require('express');
const { createTrainingRequest, coachResponse, getCoachTrainingRequests, getTrainingRequest, getMemberTrainingRequests, getAllTrainingRequests,recommendOtherTrainer  } = require('../controllers/trainingRequestController');
const router = express.Router();

// 会员向私人教练发送训练请求
router.post('/training-requests', createTrainingRequest);

// 获取训练请求的详情
router.get('/training-requests/:id', getTrainingRequest);

// 获取会员所有的训练请求
router.get('/training-requests/member/:member_id', getMemberTrainingRequests);

// 教练响应训练请求
router.put('/training-requests/response/:id', coachResponse);

// 获取教练所有的训练请求
router.get('/training-requests/coach/:coachId', getCoachTrainingRequests);

// 获取所有的训练请求记录
router.get('/training-requests', getAllTrainingRequests);  // 新增这一行

//教练推荐其他教练
router.put('/training-requests/recommend-trainer/:id', recommendOtherTrainer);

module.exports = router;
