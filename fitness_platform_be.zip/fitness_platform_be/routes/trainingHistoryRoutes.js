const express = require('express');
const router = express.Router();
const trainingHistoryController = require('../controllers/trainingHistoryController');

// POST /api/training-history: 更新训练历史
router.post('/training-history', trainingHistoryController.createTrainingHistory);

// GET /api/training-history/member/:memberId: 获取会员的训练历史
router.get('/training-history/member/:memberId', trainingHistoryController.getMemberTrainingHistory);

// GET /api/training-history/coach/:coachId: 获取教练的训练历史
router.get('/training-history/coach/:coachId', trainingHistoryController.getCoachTrainingHistory);

module.exports = router;