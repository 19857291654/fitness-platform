require('dotenv').config(); // 加载 .env 文件中的变量
const express = require('express');
const app = express();
const port = 5000; // 可以根据需求更改端口

// 导入 Sequelize 和模型
const { sequelize } = require('./models');  // 导入 sequelize 实例
const Member = require('./models/member');  // 导入 Member 模型
const Notification = require('./models/notification');
const Trainer = require('./models/trainer');
const TrainingHistory = require('./models/trainingHistory');
const TrainingRequest = require('./models/trainingRequest');
const TrainingSession = require('./models/trainingSession');

// 测试 Sequelize 数据库连接
sequelize.authenticate()
  .then(() => {
    console.log('Database connected successfully!');
  })
  .catch((err) => {
    console.error('Unable to connect to the database:', err);
  });

// 同步 Sequelize 模型到数据库
sequelize.sync({ force: false   })  // force: true 会删除已有表并重建，通常在开发时使用
  .then(() => {
    console.log('Database synchronized successfully!');
  })
  .catch((err) => {
    console.error('Error synchronizing the database:', err);
  });

// 设置一个简单的路由
app.get('/', (req, res) => {
  res.send('Welcome to the Fitness Platform Backend!');
});

// 启动服务器
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

// 启用 CORS
const cors = require('cors');
app.use(cors());
// 中间件
app.use(express.json()); // 解析 JSON 数据
// 导入路由
const memberRoutes = require('./routes/memberRoutes');
const trainerRoutes = require('./routes/trainerRoutes');
const trainingRequestRoutes = require('./routes/trainingRequestRoutes');
const trainingSessionRoutes = require('./routes/trainingSessionRoutes'); // 导入课程路由
const trainingHistoryRoutes = require('./routes/trainingHistoryRoutes'); // 引入训练历史路由

app.use('/api/members', memberRoutes); // 使用会员相关路由
app.use('/api', trainerRoutes);
app.use('/api', trainingRequestRoutes);
app.use('/api', trainingSessionRoutes); // 使用课程相关路由
app.use('/api', trainingHistoryRoutes); // 使用训练历史相关路由
