const argon2 = require('argon2'); // 使用 argon2 进行密码加密
const Member = require('../models/member');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = process.env;

class MemberService {
  // 会员注册
  static async registerMember({ name, birth_date, address, email, password }) {
    if (typeof password !== 'string') {
      throw new Error('Password must be a string');
    }
    try {
      // 使用 argon2 哈希密码
      const hashedPassword = await argon2.hash(password);
      const member = await Member.create({
        name,
        birth_date,
        address,
        email,
        password: hashedPassword,
      });
     
      return member;
    } catch (err) {
      console.error('Error:', err);
      throw err;
    }
  }

  // 获取会员信息
  static async getMemberInfo(memberId) {
    return await Member.findByPk(memberId);
  }

  // 更新会员信息
  static async updateMemberInfo(memberId, updatedInfo) {
    const member = await Member.findByPk(memberId);
    if (!member) {
      throw new Error('Member not found');
    }
    return await member.update(updatedInfo);
  }

  // 管理员审批会员
  static async approveMember(memberId) {
    const member = await Member.findByPk(memberId);
    if (!member) {
      throw new Error('Member not found');
    }
    return await member.update({ approved: true });
  }

  // 根据邮箱查找会员
  static async getMemberByEmail(email) {
    return await Member.findOne({ where: { email } });
  }
}

module.exports = MemberService;
