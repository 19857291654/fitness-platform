// models/trainingSession.js
const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('./index');
const Member = require('./member');
const Trainer = require('./trainer');

class TrainingSession extends Model {}

TrainingSession.init({
  session_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('booked', 'completed', 'cancelled'),
    defaultValue: 'booked',
  },
  location: {  // 新添加的字段
    type: DataTypes.STRING,  // 适合存储地点信息
    allowNull: true,  // 可以为空
  },
}, {
  sequelize,
  modelName: 'TrainingSession',
  tableName: 'training_sessions',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

TrainingSession.belongsTo(Member, { foreignKey: 'member_id' });
TrainingSession.belongsTo(Trainer, { foreignKey: 'trainer_id' });

module.exports = TrainingSession;
