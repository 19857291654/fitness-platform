// models/trainer.js
const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('./index');  // 导入 Sequelize 实例

class Trainer extends Model {}

Trainer.init({
  name: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  bio: {
    type: DataTypes.TEXT,
  },
  specialties: {
    type: DataTypes.STRING(255),
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
  },
}, {
  sequelize,
  modelName: 'Trainer',
  tableName: 'trainers',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

module.exports = Trainer;
