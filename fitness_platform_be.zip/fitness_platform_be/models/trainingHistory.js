// models/trainingHistory.js
const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('./index');
const Member = require('./member');  // 会员模型
const Trainer = require('./trainer');  // 教练模型
const TrainingSession = require('./trainingSession');  // 训练会话模型

class TrainingHistory extends Model {}

TrainingHistory.init(
  {
    workout_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    sets: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    reps: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    weight: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    heart_rate: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    calories_burned: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    performance: {
      type: DataTypes.BOOLEAN,  // 是否完成训练目标
      allowNull: false,
      defaultValue: false,  // 默认值为未完成
    },
    duration: {
      type: DataTypes.INTEGER,  // 训练时长（单位：分钟）
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: 'TrainingHistory',
    tableName: 'training_history',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  }
);

// 关联：每条训练历史记录都关联一个会员和教练
TrainingHistory.belongsTo(Member, { foreignKey: 'member_id' });
TrainingHistory.belongsTo(Trainer, { foreignKey: 'trainer_id' });
TrainingHistory.belongsTo(TrainingSession, { foreignKey: 'session_id' });

module.exports = TrainingHistory;
