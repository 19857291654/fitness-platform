// models/trainingRequest.js
const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('./index');
const Member = require('./member');
const Trainer = require('./trainer');

class TrainingRequest extends Model {}

TrainingRequest.init({
  goal: {
    type: DataTypes.TEXT,
  },
  status: {
    type: DataTypes.ENUM('pending', 'accepted', 'rejected', 'suggested'),
    defaultValue: 'pending',
  },
  recommended_trainer_id: {
    type: DataTypes.INTEGER,
    allowNull: true, // 允许为空
    references: {
      model: Trainer, // 关联 Trainer 模型
      key: 'id', // 外键参考 Trainer 表的 id 字段
    }
  },
}, {
  sequelize,
  modelName: 'TrainingRequest',
  tableName: 'training_requests',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

// 关系定义
TrainingRequest.belongsTo(Member, { foreignKey: 'member_id' });
TrainingRequest.belongsTo(Trainer, { foreignKey: 'trainer_id' });
TrainingRequest.belongsTo(Trainer, { foreignKey: 'recommended_trainer_id', as: 'recommendedTrainer' });

module.exports = TrainingRequest;
