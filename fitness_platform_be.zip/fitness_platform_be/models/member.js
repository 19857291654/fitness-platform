// models/member.js
const { Model, DataTypes } = require('sequelize');
const { sequelize } = require('./index');

class Member extends Model {}

Member.init({
  name: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  birth_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  address: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  approved: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  role: {
    type: DataTypes.ENUM('member', 'trainer'),  // 这里用枚举类型区分会员和教练
    allowNull: false,
    defaultValue: 'member',  // 默认值是会员
  },
}, {
  sequelize,
  modelName: 'Member',
  tableName: 'members',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

module.exports = Member;
