// models/index.js
const { Sequelize } = require('sequelize');

// 创建 Sequelize 实例
const sequelize = new Sequelize('mysql://root:123456@localhost:3306/fitness_platform');

// 测试连接
sequelize.authenticate()
  .then(() => {
    console.log('Database connected successfully!');
  })
  .catch((err) => {
    console.error('Error connecting to the database:', err);
  });

module.exports = { sequelize };  // 导出 sequelize 实例
