const mysql = require('mysql2');

// 创建连接池（可以提高性能）
const pool = mysql.createPool({
  host: 'localhost',      // 数据库地址
  user: 'root',           // 数据库用户名
  password: '123456',     // 数据库密码
  database: 'fitness_platform', // 数据库名
  port: 3306             // 数据库端口（默认是3306）
});

// 使用 promise 封装连接池
const promisePool = pool.promise();

module.exports = promisePool;
